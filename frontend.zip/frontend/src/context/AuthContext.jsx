import { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { get, post, put } from '../utils/request';
import { API_ENDPOINTS } from '../utils/endpoints';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(() => {
    const saved = localStorage.getItem('user');
    return saved ? JSON.parse(saved) : null;
  });
  const [loading, setLoading] = useState(true);

  const rawRole = String(user?.role || '').toLowerCase().trim();
  const isOwner = rawRole === 'owner';
  const isAdmin = isOwner || rawRole === 'admin';
  const isReseller = rawRole === 'reseller';
  const isMember = !isAdmin && !isReseller;

  const roleLabel = isOwner
    ? 'Owner'
    : isAdmin
    ? 'Admin'
    : isReseller
    ? 'Reseller'
    : 'Member';

  const roleTitle = isOwner
    ? 'Owner'
    : isAdmin
    ? 'Admin'
    : isReseller
    ? 'Reseller Prioritas'
    : 'Member';

  const refreshProfile = useCallback(async () => {
    try {
      const res = await get(API_ENDPOINTS.AUTH.PROFILE);
      setUser(res.data);
      localStorage.setItem('user', JSON.stringify(res.data));
      return res.data;
    } catch {
      return null;
    }
  }, []);

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (token) {
      refreshProfile().finally(() => setLoading(false));
    } else {
      setLoading(false);
    }
  }, [refreshProfile]);

  const login = async (email, password) => {
    const res = await post(API_ENDPOINTS.AUTH.LOGIN, { email, password });
    localStorage.setItem('token', res.token);
    localStorage.setItem('user', JSON.stringify(res.data));
    setUser(res.data);
    return res;
  };

  const register = async (data) => {
    const res = await post(API_ENDPOINTS.AUTH.REGISTER, data);
    localStorage.setItem('token', res.token);
    localStorage.setItem('user', JSON.stringify(res.data));
    setUser(res.data);
    return res;
  };

  const logout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    setUser(null);
  };

  const updateBalance = (balance) => {
    setUser((prev) => {
      const updated = { ...prev, balance };
      localStorage.setItem('user', JSON.stringify(updated));
      return updated;
    });
  };

  const updatePartnerName = async (partnerName) => {
    const res = await put(API_ENDPOINTS.AUTH.UPDATE_PROFILE, { partner_name: partnerName });
    setUser(res.data);
    localStorage.setItem('user', JSON.stringify(res.data));
    return res;
  };

  return (
    <AuthContext.Provider
      value={{ user, loading, isAdmin, isOwner, isReseller, isMember, roleLabel, roleTitle, rawRole, login, register, logout, refreshProfile, updateBalance, updatePartnerName }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
};
